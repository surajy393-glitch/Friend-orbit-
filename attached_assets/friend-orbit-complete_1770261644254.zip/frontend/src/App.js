import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "./components/ui/sonner";
import { useEffect, useState, createContext } from "react";
import axios from "axios";

// Pages
import Universe from "./pages/Universe";
import Setup from "./pages/Setup";
import PersonProfile from "./pages/PersonProfile";
import Settings from "./pages/Settings";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
export const API = `${BACKEND_URL}/api`;

// Context for user data
export const UserContext = createContext(null);

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      try {
        // Check for Telegram WebApp
        const tg = window.Telegram?.WebApp;
        
        if (tg?.initData) {
          // Authenticate via Telegram
          const res = await axios.post(`${API}/auth/telegram`, {
            init_data: tg.initData
          });
          setUser(res.data.user);
          
          // Expand WebApp if in Telegram
          tg.expand?.();
          tg.ready?.();
        } else {
          // Demo mode - use localStorage
          let demoId = localStorage.getItem('fo_demo_id');
          if (!demoId) {
            demoId = `demo_${Date.now()}`;
            localStorage.setItem('fo_demo_id', demoId);
          }
          
          const res = await axios.post(`${API}/auth/telegram`, {
            telegram_id: demoId,
            display_name: 'Demo User'
          });
          setUser(res.data.user);
        }
      } catch (error) {
        console.error('Auth error:', error);
        // Create fallback demo user
        const fallbackId = `demo_${Date.now()}`;
        localStorage.setItem('fo_demo_id', fallbackId);
        setUser({
          id: fallbackId,
          telegram_id: fallbackId,
          display_name: 'Demo User',
          onboarded: false
        });
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  const updateUser = (updates) => {
    setUser(prev => ({ ...prev, ...updates }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="stars-bg" />
        <div className="relative z-10 text-center">
          <div className="w-16 h-16 mx-auto rounded-full sun animate-pulse" />
          <p className="mt-4 text-slate-400 font-medium">Loading your universe...</p>
        </div>
      </div>
    );
  }

  return (
    <UserContext.Provider value={{ user, setUser, updateUser }}>
      <div className="App min-h-screen bg-background">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={user?.onboarded ? <Universe /> : <Setup />} />
            <Route path="/setup" element={<Setup />} />
            <Route path="/universe" element={<Universe />} />
            <Route path="/person/:id" element={<PersonProfile />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-center" richColors />
      </div>
    </UserContext.Provider>
  );
}

export default App;
