import requests
import json
from datetime import datetime, timezone
import sys

class FriendOrbitAPITester:
    def __init__(self):
        self.base_url = "https://orbit-beta-preview.preview.emergentagent.com/api"
        self.test_user_id = "test_user_123"
        self.user_data = {}
        self.person_ids = []
        self.meteor_ids = []
        self.tests_run = 0
        self.tests_passed = 0
        self.failed_tests = []

    def log_test(self, test_name, success, error_msg=""):
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {test_name} - PASSED")
        else:
            print(f"❌ {test_name} - FAILED: {error_msg}")
            self.failed_tests.append({"test": test_name, "error": error_msg})

    def test_health_check(self):
        """Test API health endpoint"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=10)
            success = response.status_code == 200
            self.log_test("Health Check", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Health Check", False, str(e))
            return False

    def test_telegram_auth(self):
        """Test Telegram authentication endpoint"""
        try:
            # Test demo user creation
            response = requests.post(f"{self.base_url}/auth/telegram", 
                                   json={
                                       "telegram_id": self.test_user_id,
                                       "display_name": "Test User"
                                   }, timeout=10)
            
            if response.status_code == 200:
                self.user_data = response.json().get("user", {})
                success = True
            else:
                success = False
                
            self.log_test("Telegram Auth", success, 
                         f"Status: {response.status_code}, Response: {response.text[:200]}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Telegram Auth", False, str(e))
            return False

    def test_get_user(self):
        """Test getting user by telegram ID"""
        try:
            response = requests.get(f"{self.base_url}/users/{self.test_user_id}", timeout=10)
            success = response.status_code == 200
            if success:
                user_data = response.json()
                success = user_data.get("telegram_id") == self.test_user_id
            self.log_test("Get User", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Get User", False, str(e))
            return False

    def test_update_user(self):
        """Test updating user profile"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Update User", False, "No user ID available")
                return False
                
            response = requests.patch(f"{self.base_url}/users/{user_id}",
                                    json={
                                        "display_name": "Updated Test User",
                                        "inner_circle_size": 8,
                                        "drift_strictness": "strict"
                                    }, timeout=10)
            success = response.status_code == 200
            self.log_test("Update User", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Update User", False, str(e))
            return False

    def test_onboard_user(self):
        """Test completing user onboarding"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Onboard User", False, "No user ID available")
                return False
                
            response = requests.post(f"{self.base_url}/users/{user_id}/onboard", timeout=10)
            success = response.status_code == 200
            self.log_test("Onboard User", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Onboard User", False, str(e))
            return False

    def test_create_people(self):
        """Test creating different types of people"""
        user_id = self.user_data.get("id")
        if not user_id:
            self.log_test("Create People", False, "No user ID available")
            return False

        people_to_create = [
            {
                "name": "John Partner",
                "relationship_type": "partner",
                "archetype": "Anchor",
                "cadence_days": 1
            },
            {
                "name": "Mom Smith",
                "relationship_type": "family",
                "relationship_subtype": "Mom",
                "archetype": "Sage",
                "cadence_days": 7
            },
            {
                "name": "Alice Friend",
                "relationship_type": "friend",
                "archetype": "Spark",
                "cadence_days": 14,
                "tags": ["college", "gym"]
            }
        ]

        success_count = 0
        for person in people_to_create:
            try:
                response = requests.post(f"{self.base_url}/people?user_id={user_id}",
                                       json=person, timeout=10)
                if response.status_code in [200, 201]:
                    person_data = response.json()
                    self.person_ids.append(person_data.get("id"))
                    success_count += 1
                    self.log_test(f"Create {person['name']}", True)
                else:
                    self.log_test(f"Create {person['name']}", False, 
                                 f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"Create {person['name']}", False, str(e))

        return success_count == len(people_to_create)

    def test_get_people(self):
        """Test getting all people for user"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Get People", False, "No user ID available")
                return False
                
            response = requests.get(f"{self.base_url}/people?user_id={user_id}", timeout=10)
            success = response.status_code == 200
            if success:
                people = response.json()
                success = isinstance(people, list) and len(people) > 0
            self.log_test("Get People", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Get People", False, str(e))
            return False

    def test_log_interaction(self):
        """Test logging interaction with person"""
        try:
            if not self.person_ids:
                self.log_test("Log Interaction", False, "No person IDs available")
                return False
                
            person_id = self.person_ids[0]
            response = requests.post(f"{self.base_url}/people/{person_id}/interaction", timeout=10)
            success = response.status_code == 200
            self.log_test("Log Interaction", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Log Interaction", False, str(e))
            return False

    def test_create_meteors(self):
        """Test creating memory meteors"""
        user_id = self.user_data.get("id")
        if not user_id or not self.person_ids:
            self.log_test("Create Meteors", False, "No user ID or person IDs available")
            return False

        meteors_to_create = [
            {
                "person_id": self.person_ids[0],
                "content": "Ask about their new job",
                "tag": "work"
            },
            {
                "person_id": self.person_ids[0],
                "content": "Remember birthday next month"
            }
        ]

        success_count = 0
        for meteor in meteors_to_create:
            try:
                response = requests.post(f"{self.base_url}/meteors?user_id={user_id}",
                                       json=meteor, timeout=10)
                if response.status_code in [200, 201]:
                    meteor_data = response.json()
                    self.meteor_ids.append(meteor_data.get("id"))
                    success_count += 1
                    self.log_test(f"Create Meteor: {meteor['content'][:20]}...", True)
                else:
                    self.log_test(f"Create Meteor: {meteor['content'][:20]}...", False, 
                                 f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"Create Meteor: {meteor['content'][:20]}...", False, str(e))

        return success_count == len(meteors_to_create)

    def test_get_meteors(self):
        """Test getting meteors for user/person"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Get Meteors", False, "No user ID available")
                return False
                
            response = requests.get(f"{self.base_url}/meteors?user_id={user_id}", timeout=10)
            success = response.status_code == 200
            if success:
                meteors = response.json()
                success = isinstance(meteors, list)
            self.log_test("Get Meteors", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Get Meteors", False, str(e))
            return False

    def test_update_meteor(self):
        """Test updating meteor status"""
        try:
            if not self.meteor_ids:
                self.log_test("Update Meteor", False, "No meteor IDs available")
                return False
                
            meteor_id = self.meteor_ids[0]
            response = requests.patch(f"{self.base_url}/meteors/{meteor_id}",
                                    json={"done": True}, timeout=10)
            success = response.status_code == 200
            self.log_test("Update Meteor", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Update Meteor", False, str(e))
            return False

    def test_battery_logging(self):
        """Test battery score logging and suggestions"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Battery Logging", False, "No user ID available")
                return False
                
            # Log battery score
            response = requests.post(f"{self.base_url}/battery?user_id={user_id}&score=75", timeout=10)
            success = response.status_code == 200
            if success:
                battery_data = response.json()
                success = "suggestions" in battery_data and "score" in battery_data
            self.log_test("Battery Logging", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Battery Logging", False, str(e))
            return False

    def test_get_battery_status(self):
        """Test getting battery status"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("Get Battery Status", False, "No user ID available")
                return False
                
            response = requests.get(f"{self.base_url}/battery/{user_id}", timeout=10)
            success = response.status_code == 200
            if success:
                battery_status = response.json()
                success = "score" in battery_status
            self.log_test("Get Battery Status", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("Get Battery Status", False, str(e))
            return False

    def test_user_stats(self):
        """Test getting user statistics"""
        try:
            user_id = self.user_data.get("id")
            if not user_id:
                self.log_test("User Stats", False, "No user ID available")
                return False
                
            response = requests.get(f"{self.base_url}/stats/{user_id}", timeout=10)
            success = response.status_code == 200
            if success:
                stats = response.json()
                success = "total_people" in stats and "by_type" in stats
            self.log_test("User Stats", success, 
                         f"Status: {response.status_code}" if not success else "")
            return success
        except Exception as e:
            self.log_test("User Stats", False, str(e))
            return False

    def run_all_tests(self):
        """Run all API tests in sequence"""
        print("🚀 Starting Friend Orbit API Tests...")
        print(f"Testing against: {self.base_url}\n")

        # Core API tests
        test_methods = [
            self.test_health_check,
            self.test_telegram_auth,
            self.test_get_user,
            self.test_update_user,
            self.test_onboard_user,
            self.test_create_people,
            self.test_get_people,
            self.test_log_interaction,
            self.test_create_meteors,
            self.test_get_meteors,
            self.test_update_meteor,
            self.test_battery_logging,
            self.test_get_battery_status,
            self.test_user_stats
        ]

        for test_method in test_methods:
            print()
            try:
                test_method()
            except Exception as e:
                print(f"❌ {test_method.__name__} - CRITICAL ERROR: {str(e)}")
                self.tests_run += 1
                self.failed_tests.append({
                    "test": test_method.__name__,
                    "error": f"Critical error: {str(e)}"
                })

        self.print_summary()
        return self.tests_passed == self.tests_run

    def print_summary(self):
        """Print test execution summary"""
        print("\n" + "="*50)
        print("📊 TEST SUMMARY")
        print("="*50)
        print(f"Tests Run: {self.tests_run}")
        print(f"Passed: {self.tests_passed}")
        print(f"Failed: {len(self.failed_tests)}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run)*100:.1f}%" if self.tests_run > 0 else "0%")
        
        if self.failed_tests:
            print(f"\n❌ FAILED TESTS:")
            for failed in self.failed_tests:
                print(f"  • {failed['test']}: {failed['error']}")
        
        print("="*50)

def main():
    tester = FriendOrbitAPITester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())