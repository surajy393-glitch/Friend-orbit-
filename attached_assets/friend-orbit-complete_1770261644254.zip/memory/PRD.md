# Friend Orbit - Product Requirements Document

## Original Problem Statement
Build an MVP for a Telegram-based social relationship manager called "Friend Orbit" - a system where users manage their relationships as a universe, with friends/family as planets orbiting around them based on interaction frequency.

## User Token
`TELEGRAM_BOT_TOKEN=8051818960:AAEDhFC2eqZpp01Ef6Ukq0sTN7Ylv2TaRw4`
Bot Username: `@Friendorbitbot`

## Core Features (MVP)
1. **Telegram Bot Integration** - Entry point via Telegram
2. **Web App** - Space-themed UI for managing relationships
3. **Gravity System** - Relationships decay over time without interaction
4. **Battery Check** - Daily mood/energy logging with suggestions
5. **Notifications** - Server-side cron for reminders

## Product Requirements
1. **LLM Integration:** No AI for MVP - rule-based suggestions only
2. **Data Persistence:** MongoDB with minimal data storage
3. **Privacy:** Soft delete/archive, basic privacy note
4. **Notifications:**
   - Daily battery prompt: 10:00 AM IST
   - Weekly drift digest: Sunday 7:00 PM IST

## What's Been Implemented ✅

### Backend (FastAPI + MongoDB)
- User authentication (Telegram + demo mode)
- People (planets) CRUD operations
- Meteor (memories) CRUD operations
- Battery logging with suggestions
- Invite system for connecting users
- Gravity decay calculations
- Telegram webhook handler with /start, callbacks
- APScheduler for gravity decay cron job

### Frontend (React + TailwindCSS)
- Space-themed UI design
- Onboarding wizard (3 steps)
- Universe map view with orbiting planets
- Person profile view
- Battery prompt modal
- Add planet modal
- Settings page

### Telegram Bot ✅
- Webhook configured and active
- /start command with welcome message
- "Open Friend Orbit" Web App button
- "How it works" and "Privacy" info buttons
- Invite acceptance flow

## What's Pending

### P0 - Critical
- [ ] Cron jobs for notifications (battery prompt, drift digest) - scheduled but notifications not sent
- [ ] Test Web App launch from Telegram button

### P1 - Important  
- [ ] Minor frontend bugs (modal timing, state sync)
- [ ] Complete gravity calculation endpoint

### P2 - Nice to Have
- [ ] Configurable notification timings
- [ ] AI-powered suggestions (Phase 2)

## Technical Architecture
```
/app
├── backend/
│   ├── server.py       # FastAPI main app with all routes
│   ├── requirements.txt
│   └── .env            # Contains TELEGRAM_BOT_TOKEN, MONGO_URL
├── frontend/
│   ├── src/
│   │   ├── components/ # React components (15+)
│   │   └── App.js      # Main router
│   ├── public/
│   │   └── index.html  # Entry point (badge removed)
│   └── package.json
└── memory/
    └── PRD.md          # This file
```

## API Endpoints
- `POST /api/auth/telegram` - Telegram auth
- `POST /api/users` - Create user
- `GET/POST /api/people` - Manage planets
- `POST /api/people/{id}/interaction` - Log interaction
- `GET/POST /api/meteors` - Manage memories
- `POST /api/battery` - Log battery score
- `POST /api/invites` - Generate invite
- `POST /api/telegram/webhook/{secret}` - Telegram updates

## Database Schema
- **users**: id, telegram_id, display_name, timezone, onboarded, last_battery
- **people**: id, user_id, name, relationship_type, archetype, gravity_score, pinned, archived
- **meteors**: id, person_id, user_id, content, tag, done, archived
- **battery_logs**: id, user_id, score, created_at
- **invites**: id, token, inviter_id, person_id, status, expires_at

## Session Updates (Feb 4, 2026)
- ✅ Removed "Made with Emergent" badge from website
- ✅ Set up Telegram webhook - bot now responding to /start
- ✅ Updated page title and description to "Friend Orbit"
